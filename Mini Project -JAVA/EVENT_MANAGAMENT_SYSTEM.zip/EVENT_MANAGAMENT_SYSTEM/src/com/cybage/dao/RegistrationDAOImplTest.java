package com.cybage.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RegistrationDAOImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
