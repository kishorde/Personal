package com.cybage.jdbc;

public class StudentDemoUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
