package com.cybage.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.model.Product;

@Service
public class ProductService {
	
	List<Product> productList = new ArrayList<>();
	
	public ProductService()
	{
		productList.add(new Product (101,"Pendrive",200));
		productList.add(new Product (102,"Mobile",15000));
		productList.add(new Product (103,"Laptop",50000));
		productList.add(new Product (104,"Headphone",3000));
	}
	
	public List<Product> getAllProduct()
	{
		return productList;
	}
}
