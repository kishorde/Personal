function showPerson(person) {
    console.log("".concat(person.name, "    ").concat(person.age, "     ").concat(person.dob));
}
showPerson({ name: "chicku", age: 20, dob: "11/11/2002" });
