var msg = "hello";
