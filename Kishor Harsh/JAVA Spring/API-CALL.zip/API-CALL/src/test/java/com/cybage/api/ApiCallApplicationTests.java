package com.cybage.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCallApplicationTests {

	@Test
	void contextLoads() {
	}

}
